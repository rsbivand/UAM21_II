## ---- echo=TRUE------------------------------------------------------------------------
needed <- c("gstat", "spatstat", "spatstat.linnet", "spatstat.core", 
"spatstat.geom", "spatstat.data", "ggplot", "igraph", "spdep", 
"spData", "sp", "tmap", "tidycensus", "sf")


## ---- eval=TRUE------------------------------------------------------------------------
library(sf)
library(tidycensus)
options(tigris_use_cache=TRUE)


## ---- eval=FALSE-----------------------------------------------------------------------
## census_api_key("MY_KEY")


## ---- eval=TRUE------------------------------------------------------------------------
(us <- unique(fips_codes$state)[c(1, 3:11, 13:51)])


## ---- eval=FALSE-----------------------------------------------------------------------
## f <- function(x) {
##   get_acs(geography="tract", variables=c(tot_pop="B01003_001"), year=2010,
##           state=x, geometry=TRUE)
## }
## mp <- lapply(us, f)
## map10 <- do.call("rbind", mp)


## ---- eval=FALSE-----------------------------------------------------------------------
## f <- function(x) {
##   get_acs(geography="tract", variables=c(median_income="B19013_001"), year=2010, state=x)
## }
## mp <- lapply(us, f)
## med_inc_acs10 <- do.call("rbind", mp)


## ---- eval=FALSE-----------------------------------------------------------------------
## f <- function(x) {
##   get_decennial(geography="tract", variables=c(tot_pop="P001001", tot_hu="H001001", vacant="H003003", group_pop="P042001", black_tot="P008004", hisp_tot="P004003", m70_74="P012022", m75_79="P012023", m80_84="P012024", m85p="P012025", f70_74="P012046", f75_79="P012047", f80_84="P012048", f85p="P012049"), year=2010, state=x, output="wide")
## }
## mp <- lapply(us, f)
## cen10 <- do.call("rbind", mp)


## ---- eval=FALSE-----------------------------------------------------------------------
## df <- merge(map10, med_inc_acs10, by="GEOID")
## df1 <- df[,-c(2, 3, 6, 7)]
## names(df1) <- c("GEOID", "tot_pop_acs", "tot_pop_moe", "med_inc_acs", "med_inc_moe", "geometry")
## names(attr(df1, "agr")) <- names(df1)[-6]


## ---- eval=FALSE-----------------------------------------------------------------------
## df_tracts_a <- merge(df1, cen10, by="GEOID")
## df_tracts <- df_tracts_a[df_tracts_a$tot_pop > 500 & df_tracts_a$tot_hu > 200,]
## df_tracts <- df_tracts[!is.na(df_tracts$med_inc_moe),]


## ---- eval=FALSE-----------------------------------------------------------------------
## df_tracts$tot_pop_cv <- (df_tracts$tot_pop_moe/1.645)/df_tracts$tot_pop_acs
## df_tracts$med_inc_cv <- (df_tracts$med_inc_moe/1.645)/df_tracts$med_inc_acs


## ---- eval=FALSE-----------------------------------------------------------------------
## df_tracts$old_rate <- sum(as.data.frame(df_tracts)[,13:20])/df_tracts$tot_pop
## df_tracts$black_rate <- df_tracts$black_tot/df_tracts$tot_pop
## df_tracts$hisp_rate <- df_tracts$hisp_tot/df_tracts$tot_pop
## df_tracts$vacancy_rate <- df_tracts$vacant/df_tracts$tot_hu


## ---- eval=FALSE-----------------------------------------------------------------------
## library(s2)
## df_tracts$area <- NISTunits::NISTsqrMeterTOacre(st_area(df_tracts))
## df_tracts$dens <- df_tracts$tot_pop/df_tracts$area
## st_write(df_tracts, "df_tracts.gpkg", append=FALSE)


## ---- eval=TRUE------------------------------------------------------------------------
# df_tracts <- st_read("df_tracts.gpkg")


## ---- eval=TRUE------------------------------------------------------------------------
# chicago_MA <- read.table("Chicago_MA.txt", colClasses=c("character", "character"))
# chicago_MA_tracts <- !is.na(match(substring(df_tracts$GEOID, 1, 5), chicago_MA$V2))
# sum(chicago_MA_tracts)


## ---- eval=TRUE------------------------------------------------------------------------
# library(tmap)
# tm_shape(df_tracts[chicago_MA_tracts,]) + tm_fill("med_inc_cv", style="fisher", n=7, title="Coefficient of Variation")


## ---- eval=TRUE------------------------------------------------------------------------
# df_tracts$mi_cv_esri <- cut(df_tracts$med_inc_cv, c(0, 0.12, 0.40, Inf), labels=c("High", "Medium", "Low"), right=TRUE, include.lowest=TRUE, ordered_result=TRUE)
# table(df_tracts$mi_cv_esri)


## ---- eval=TRUE------------------------------------------------------------------------
# tm_shape(df_tracts[chicago_MA_tracts,]) + tm_fill("mi_cv_esri", title="Reliability")


## ---- eval=TRUE------------------------------------------------------------------------
# tmap_mode("view")
# tm_shape(df_tracts[chicago_MA_tracts,]) + tm_fill("mi_cv_esri", title="Reliability")
# tmap_mode("plot")


## ---- eval=FALSE-----------------------------------------------------------------------
## library(mapview)
## mapviewOptions(fgb = FALSE)
## mapview(df_tracts[chicago_MA_tracts,"med_inc_cv"], layer.name="Coefficient of Variation")


## --------------------------------------------------------------------------------------
data(pol_pres15, package="spDataLarge")
pol_pres15 |> 
    subset(select=c(TERYT, name, types)) |> 
    head()


## ----plotpolpres15---------------------------------------------------------------------
library(tmap)
tm_shape(pol_pres15) + tm_fill("types")


## --------------------------------------------------------------------------------------
library(spdep)


## --------------------------------------------------------------------------------------
args(poly2nb)


## --------------------------------------------------------------------------------------
system.time(pol_pres15 |> poly2nb(queen=TRUE) -> nb_q)


## --------------------------------------------------------------------------------------
nb_q


## --------------------------------------------------------------------------------------
system.time(pol_pres15 |> poly2nb(queen=TRUE, small_n=2500) -> nb_q_legacy)


## --------------------------------------------------------------------------------------
all.equal(nb_q, nb_q_legacy, check.attributes=FALSE)


## --------------------------------------------------------------------------------------
(nb_q |> n.comp.nb())$nc


## --------------------------------------------------------------------------------------
library(Matrix)
nb_q |> 
    nb2listw(style="B") |> 
    as("CsparseMatrix") -> smat
library(igraph)
(smat |> 
        graph.adjacency() -> g1) |> 
    count_components()


## --------------------------------------------------------------------------------------
tf <- tempfile(fileext=".gal")
write.nb.gal(nb_q, tf)


## --------------------------------------------------------------------------------------
pol_pres15 |> 
    st_geometry() |> 
    st_centroid(of_largest_polygon=TRUE) -> coords 
(coords |> tri2nb() -> nb_tri)


## --------------------------------------------------------------------------------------
nb_tri |> 
    nbdists(coords) |> 
    unlist() |> 
    summary()


## --------------------------------------------------------------------------------------
(nb_tri |> n.comp.nb())$nc


## --------------------------------------------------------------------------------------
(nb_tri |> 
        soi.graph(coords) |> 
        graph2nb() -> nb_soi)


## --------------------------------------------------------------------------------------
(nb_soi |> n.comp.nb() -> n_comp)$nc


## --------------------------------------------------------------------------------------
table(n_comp$comp.id)


## ----plotnbdiff------------------------------------------------------------------------
opar <- par(mar=c(0,0,0,0)+0.5)
pol_pres15 |> 
    st_geometry() |> 
    plot(border="grey", lwd=0.5)
nb_soi |> 
    plot(coords=coords, add=TRUE, points=FALSE, lwd=0.5)
nb_tri |> 
    diffnb(nb_soi) |> 
    plot(coords=coords, col="orange", add=TRUE, points=FALSE, lwd=0.5)
par(opar)


## --------------------------------------------------------------------------------------
coords |> 
    knearneigh(k=1) |> 
    knn2nb() |> 
    nbdists(coords) |> 
    unlist() |> 
    summary()


## --------------------------------------------------------------------------------------
system.time(coords |> dnearneigh(0, 18000) -> nb_d18)
system.time(coords |> dnearneigh(0, 18000, use_kd_tree=FALSE) -> nb_d18a)
all.equal(nb_d18, nb_d18a, check.attributes=FALSE)
nb_d18


## --------------------------------------------------------------------------------------
(nb_d18 |> n.comp.nb() -> n_comp)$nc

## --------------------------------------------------------------------------------------
table(n_comp$comp.id)


## --------------------------------------------------------------------------------------
(coords |> dnearneigh(0, 18300) -> nb_d183)

## --------------------------------------------------------------------------------------
(nb_d183 |> n.comp.nb())$nc


## --------------------------------------------------------------------------------------
(coords |> dnearneigh(0, 16000) -> nb_d16)


## --------------------------------------------------------------------------------------
(coords |> knearneigh(k=6) -> knn_k6) |> knn2nb()


## --------------------------------------------------------------------------------------
(knn_k6 |> knn2nb(sym=TRUE) -> nb_k6s)


## --------------------------------------------------------------------------------------
(nb_k6s |> n.comp.nb())$nc


## --------------------------------------------------------------------------------------
args(nb2listw)


## --------------------------------------------------------------------------------------
args(spweights.constants)


## --------------------------------------------------------------------------------------
(nb_q |> 
        nb2listw(style="B") -> lw_q_B) |> 
    spweights.constants() |> 
    data.frame() |> 
    subset(select=c(n, S0, S1, S2))


## --------------------------------------------------------------------------------------
(nb_q |> 
        nb2listw(style="W") -> lw_q_W) |> 
    spweights.constants() |> 
    data.frame() |> 
    subset(select=c(n, S0, S1, S2))


## --------------------------------------------------------------------------------------
nb_d183 |> 
    nbdists(coords) |> 
    lapply(\(x) 1/(x/1000)) -> gwts
(nb_d183 |> nb2listw(glist=gwts, style="B") -> lw_d183_idw_B) |> 
    spweights.constants() |> 
    data.frame() |> 
    subset(select=c(n, S0, S1, S2))


## --------------------------------------------------------------------------------------
try(nb_d16 |> nb2listw(style="B") -> lw_d16_B)


## --------------------------------------------------------------------------------------
nb_d16 |> 
    nb2listw(style="B", zero.policy=TRUE) |> 
    spweights.constants(zero.policy=TRUE) |> 
    data.frame() |> 
    subset(select=c(n, S0, S1, S2))


## --------------------------------------------------------------------------------------
nb_q


## --------------------------------------------------------------------------------------
(nb_q |> nblag(2) -> nb_q2)[[2]]


## --------------------------------------------------------------------------------------
nblag_cumul(nb_q2)


## --------------------------------------------------------------------------------------
union.nb(nb_q2[[2]], nb_q2[[1]])


## --------------------------------------------------------------------------------------
diameter(g1)


## --------------------------------------------------------------------------------------
g1 |> shortest.paths() -> sps
(sps |> apply(2, max) -> spmax) |> max()


## --------------------------------------------------------------------------------------
mr <- which.max(spmax)
pol_pres15$name0[mr]


## ---- echo=FALSE-----------------------------------------------------------------------
pol_pres15$sps1 <- sps[,mr]
tm1 <- tm_shape(pol_pres15) + tm_fill("sps1", title="Shortest path\ncount")


## ---- echo=FALSE-----------------------------------------------------------------------
coords[mr] |> 
    st_distance(coords) |> 
    c() |> 
    (\(x) x/1000)() |> 
    units::set_units(NULL) -> pol_pres15$dist_52
library(ggplot2)
g1 <- ggplot(pol_pres15, aes(x=sps1, y=dist_52)) + geom_point() + xlab("shortest path count") +  ylab("km distance")


## ----shortestpath----------------------------------------------------------------------
gridExtra::grid.arrange(tmap_grob(tm1), g1, nrow=1)


## ---- eval=FALSE-----------------------------------------------------------------------
## library(spdep)
## t0 <- system.time(nb_subset <- poly2nb(df_tracts, queen=TRUE, row.names=map10$GEOID))
## saveRDS(nb_subset, file="nb_subset.rds")
## #   user  system elapsed
## # 24.233   0.129  24.417


## ---- eval=TRUE------------------------------------------------------------------------
# library(spdep)
# (nb_subset <- readRDS("nb_subset.rds"))


## ---- echo=TRUE------------------------------------------------------------------------
suppressPackageStartupMessages(library(spatstat))
intenfun <- function(x, y) 200 * x
set.seed(1)
(ihpp <- rpoispp(intenfun, lmax = 200))


## ---- echo=TRUE, out.width='90%', fig.align='center'-----------------------------------
plot(density(ihpp), axes=TRUE)
points(ihpp, col="green2", pch=19)


## ---- echo=TRUE, out.width='90%', fig.align='center'-----------------------------------
opar <- par(mfrow=c(1,2))
plot(envelope(ihpp, Kest, verbose=FALSE), main="Homogeneous")
plot(envelope(ihpp, Kinhom, verbose=FALSE), main="Inhomogeneous")
par(opar)


## ---- echo=TRUE, out.width='90%', fig.align='center'-----------------------------------
library(sf)
sf_ihpp <- subset(st_as_sf(ihpp, crs=32662), label == "point")
#st_as_sf(ihpp) %>% dplyr::filter(label == "point") -> sf_ihpp
#st_as_sf(ihpp) ->.; .[.$label == "point",] -> sf_ihpp
crds <- st_coordinates(sf_ihpp)
sf_ihpp$x <- crds[,1]
sf_ihpp$y <- 100 + 50 * sf_ihpp$x + 20 * rnorm(nrow(sf_ihpp))
plot(sf_ihpp[,"y"], pch=19)


## ---- echo=TRUE, out.width='90%', fig.align='center'-----------------------------------
suppressPackageStartupMessages(library(gstat))
vg0 <- variogram(y ~ 1, sf_ihpp)
vg1 <- variogram(y ~ x, sf_ihpp)
library(ggplot2)
g0 <- ggplot(vg0, aes(x=dist, y=gamma)) + geom_point() + geom_smooth(span=1) + ylim(300, 575) + ggtitle("Trend ignored")
g1 <- ggplot(vg1, aes(x=dist, y=gamma)) + geom_point() + geom_smooth(span=1) + ylim(300, 575) + ggtitle("Trend included")
gridExtra::grid.arrange(g0, g1, ncol=2)


## ---- echo=TRUE, results='hide', message=FALSE-----------------------------------------
suppressPackageStartupMessages(library(spdep))
nb_tri <- tri2nb(crds)


## ---- echo=TRUE------------------------------------------------------------------------
(nb_soi <- graph2nb(soi.graph(nb_tri, crds), sym=TRUE))


## ---- echo=TRUE, out.width='90%', fig.align='center'-----------------------------------
plot(nb_soi, crds)


## ---- echo=TRUE------------------------------------------------------------------------
comps <- n.comp.nb(nb_soi)
sf_ihpp$comps <- comps$comp.id
comps$nc


## ---- echo=TRUE, warning=FALSE, message=FALSE------------------------------------------
lwB <- nb2listw(nb_soi, style="B")
out <- broom::tidy(moran.test(sf_ihpp$y, listw=lwB, randomisation=FALSE, alternative="two.sided"))[1:5]
names(out)[1:3] <- c("Moran's I", "Expectation", "Variance"); out


## ---- echo=TRUE------------------------------------------------------------------------
lm_obj <- lm(y ~ x, data=sf_ihpp)
out <- broom::tidy(lm.morantest(lm_obj, listw=lwB, alternative="two.sided"))[1:5]
names(out)[1:3] <- c("Moran's I", "Expectation", "Variance"); out


## ---- echo=TRUE------------------------------------------------------------------------
lmor0 <- localmoran(sf_ihpp$y, listw=lwB, alternative="two.sided")
lmor1 <- as.data.frame(localmoran.sad(lm_obj, nb=nb_soi, style="B", alternative="two.sided"))
sf_ihpp$z_value <- lmor0[,4]
sf_ihpp$z_lmor1_N <- lmor1[,2]
sf_ihpp$z_lmor1_SAD <- lmor1[,4]


## ---- echo=TRUE, warning=FALSE, out.width='90%', fig.align='center', width=7, height=4----
suppressPackageStartupMessages(library(tmap))
tm_shape(sf_ihpp) + tm_symbols(col=c("z_value", "z_lmor1_N", "z_lmor1_SAD"), midpoint=0) + tm_facets(free.scales=FALSE, nrow=1) + tm_layout(panel.labels=c("No trend", "Trend, normal", "Trend, SAD"))


## ---- echo=TRUE------------------------------------------------------------------------
library(sf)
nc <- st_read(system.file("shapes/sids.shp", package="spData")[1], quiet=TRUE)
st_crs(nc) <- "+proj=longlat +datum=NAD27"
row.names(nc) <- as.character(nc$FIPSNO)
head(nc)


## ---- echo=TRUE, warning=FALSE---------------------------------------------------------
library(spdep)
gal_file <- system.file("weights/ncCR85.gal", package="spData")[1]
ncCR85 <- read.gal(gal_file, region.id=nc$FIPSNO)
ncCR85


## ---- echo=TRUE, warning=TRUE, out.width='90%', fig.align='center', width=7, height=4----
plot(st_geometry(nc), border="grey")
plot(ncCR85, st_centroid(st_geometry(nc), of_largest_polygon), add=TRUE, col="blue")


## ---- echo=TRUE------------------------------------------------------------------------
set.seed(1)
nc$rand <- rnorm(nrow(nc))
lw <- nb2listw(ncCR85, style="B")
moran.test(nc$rand, listw=lw, alternative="two.sided")


## ---- echo=TRUE------------------------------------------------------------------------
nc$LM <- as.numeric(interaction(nc$L_id, nc$M_id))
alpha <- 1
beta <- 0.5
sigma <- 2
nc$trend <- alpha + beta*nc$LM + sigma*nc$rand
moran.test(nc$trend, listw=lw, alternative="two.sided")


## ---- echo=TRUE------------------------------------------------------------------------
lm.morantest(lm(trend ~ LM, nc), listw=lw, alternative="two.sided")


## ---- echo=TRUE------------------------------------------------------------------------
aggLM <- aggregate(nc[,"LM"], list(nc$LM), head, n=1)
(aggnb <- poly2nb(aggLM))


## ---- echo=TRUE------------------------------------------------------------------------
set.seed(1)
LMrand <- rnorm(nrow(aggLM))


## ---- echo=TRUE------------------------------------------------------------------------
moran.test(LMrand, nb2listw(aggnb, style="B"))


## ---- echo=TRUE------------------------------------------------------------------------
nc$LMrand <- LMrand[match(nc$LM, aggLM$LM)]
plot(nc[,"LMrand"])


## ---- echo=TRUE------------------------------------------------------------------------
moran.test(nc$LMrand, listw=lw, alternative="two.sided")


## ----sI, echo = TRUE-------------------------------------------------------------------
sessionInfo()

