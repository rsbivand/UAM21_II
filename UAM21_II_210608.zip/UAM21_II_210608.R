
## ---- echo=TRUE------------------------------------------------------------------------
needed <- c("rgeoda", "digest", "ggplot2", "tmap", "spdep", "spData", "sp", "sf")


## --------------------------------------------------------------------------------------
library(sf)


## --------------------------------------------------------------------------------------
data(pol_pres15, package="spDataLarge")
pol_pres15 |> 
    subset(select=c(TERYT, name, types)) |> 
    head()


## --------------------------------------------------------------------------------------
library(spdep)
pol_pres15 |> poly2nb(queen=TRUE) -> nb_q
nb_q |> nb2listw(style="B") -> lw_q_B
nb_q |> nb2listw(style="W") -> lw_q_W


## --------------------------------------------------------------------------------------
pol_pres15 |> st_geometry() |> st_centroid(of_largest_polygon=TRUE) -> coords 
coords |> dnearneigh(0, 18300) -> nb_d183
nb_d183 |> nbdists(coords) |> lapply(\(x) 1/(x/1000)) -> gwts
nb_d183 |> nb2listw(glist=gwts, style="B") -> lw_d183_idw_B


## --------------------------------------------------------------------------------------
set.seed(1)
glance_htest <- function(ht) c(ht$estimate, 
    "Std deviate"=unname(ht$statistic), 
    "p.value"=unname(ht$p.value))
(pol_pres15 |> 
        nrow() |> 
        rnorm() -> x) |> 
    moran.test(lw_q_B, randomisation=FALSE, alternative="two.sided") |> 
    glance_htest()


## --------------------------------------------------------------------------------------
beta <- 0.0015
coords |> 
    st_coordinates() |> 
    subset(select=1, drop=TRUE) |> 
    (\(x) x/1000)() -> t
(x + beta * t -> x_t) |> 
    moran.test(lw_q_B, randomisation=FALSE, alternative="two.sided") |> 
    glance_htest()


## --------------------------------------------------------------------------------------
lm(x_t ~ t) |> 
    lm.morantest(lw_q_B, alternative="two.sided") |> 
    glance_htest()


## --------------------------------------------------------------------------------------
args(joincount.test)


## --------------------------------------------------------------------------------------
(pol_pres15 |> 
        st_drop_geometry() |> 
        subset(select=types, drop=TRUE) -> Types) |> 
    table()


## --------------------------------------------------------------------------------------
Types |> joincount.multi(listw=lw_q_B)


## --------------------------------------------------------------------------------------
Types |> joincount.multi(listw=lw_d183_idw_B)


## --------------------------------------------------------------------------------------
args(moran.test)


## --------------------------------------------------------------------------------------
(pol_pres15 |> 
        st_drop_geometry() |> 
        subset(select=I_turnout, drop=TRUE) -> z) |> 
    moran.test(listw=lw_q_B, randomisation=FALSE) |> 
    glance_htest()


## --------------------------------------------------------------------------------------
lm(I_turnout ~ 1, pol_pres15) |> 
    lm.morantest(listw=lw_q_B) |> 
    glance_htest()


## --------------------------------------------------------------------------------------
(z |> 
    moran.test(listw=lw_q_B) -> mtr) |> 
    glance_htest()


## --------------------------------------------------------------------------------------
set.seed(1)
z |> 
    moran.mc(listw=lw_q_B, nsim=999, return_boot = TRUE) -> mmc


## --------------------------------------------------------------------------------------
c("Permutation bootstrap"=var(mmc$t), 
  "Analytical randomisation"=unname(mtr$estimate[3]))


## --------------------------------------------------------------------------------------
# df_tracts <- st_read("df_tracts.gpkg")


## --------------------------------------------------------------------------------------
# (nb_subset <- readRDS("nb_subset.rds"))


## --------------------------------------------------------------------------------------
# nc_nb_subset <- n.comp.nb(nb_subset)
# nc_nb_subset$nc
# table(table(nc_nb_subset$comp.id))


## --------------------------------------------------------------------------------------
# set.ZeroPolicyOption(TRUE)
# lw <- nb2listw(nb_subset, style="W")


## --------------------------------------------------------------------------------------
# system.time(mt_med_inc_cv <- moran.test(df_tracts$med_inc_cv, lw, alternative="two.sided"))


## --------------------------------------------------------------------------------------
# mt_med_inc_cv


## --------------------------------------------------------------------------------------
# form <- log(med_inc_cv) ~ log1p(vacancy_rate) + log1p(old_rate) + log1p(black_rate) + log1p(hisp_rate) + log1p(group_pop) + log1p(dens)


## --------------------------------------------------------------------------------------
# lm_mod <- lm(form, data=df_tracts)
# summary(lm_mod)


## --------------------------------------------------------------------------------------
# lm.morantest(lm_mod, lw)


## ----moranplot-------------------------------------------------------------------------
z |> moran.plot(listw=lw_q_W, labels=pol_pres15$TERYT, cex=1, pch=".", xlab="I round turnout", ylab="lagged turnout") -> infl_W


## ----moranhat--------------------------------------------------------------------------
pol_pres15$hat_value <- infl_W$hat
library(tmap)
tm_shape(pol_pres15) + tm_fill("hat_value")


## --------------------------------------------------------------------------------------
z |> 
    localmoran(listw=lw_q_W, alternative="two.sided") -> locm

## --------------------------------------------------------------------------------------
all.equal(sum(locm[,1])/Szero(lw_q_W), unname(moran.test(z, lw_q_W)$estimate[1]))


## --------------------------------------------------------------------------------------
pva <- \(pv) cbind("none"=pv, "bonferroni"=p.adjust(pv, "bonferroni"), "fdr"=p.adjust(pv, "fdr"), "BY"=p.adjust(pv, "BY"))
locm |> 
    subset(select="Pr(z != 0)", drop=TRUE) |> 
    pva() -> pvsp
f <- \(x) sum(x < 0.05)
apply(pvsp, 2, f)


## --------------------------------------------------------------------------------------
library(parallel)
set.coresOption(ifelse(detectCores() == 1, 1, detectCores()-1L))
system.time(z |> 
        localmoran_perm(listw=lw_q_W, nsim=499, alternative="two.sided", iseed=1) -> locm_p)


## --------------------------------------------------------------------------------------
locm_p |> 
    subset(select="Pr(z != 0)", drop=TRUE) |> 
    pva() -> pvsp
apply(pvsp, 2, f)


## --------------------------------------------------------------------------------------
brks <- qnorm(c(0, 0.00001, 0.0001, 0.001, 0.01, 0.025, 0.5, 0.975, 0.99, 0.999, 0.9999, 0.99999, 1))
(locm_p |> 
        subset(select=Z.Ii, drop=TRUE) |> 
        cut(brks) |> 
        table()-> tab)


## --------------------------------------------------------------------------------------
sum(tab[c(1:5, 8:12)])


## --------------------------------------------------------------------------------------
sum(tab[c(1, 12)])


## --------------------------------------------------------------------------------------
z |> 
    localmoran(listw=lw_q_W, conditional=TRUE, alternative="two.sided") -> locm_c


## --------------------------------------------------------------------------------------
locm_c |> 
    subset(select="Pr(z != 0)", drop=TRUE) |> 
    pva() -> pvsp
apply(pvsp, 2, f)


## ----localmoranZ-----------------------------------------------------------------------
pol_pres15$locm_Z <- locm[, "Z.Ii"]
pol_pres15$locm_c_Z <- locm_c[, "Z.Ii"]
pol_pres15$locm_p_Z <- locm_p[, "Z.Ii"]
tm_shape(pol_pres15) + tm_fill(c("locm_Z", "locm_c_Z", "locm_p_Z"), breaks=brks, midpoint=0, title="Standard deviates of\nLocal Moran's I") + tm_facets(free.scales=FALSE, ncol=2) + tm_layout(panel.labels=c("Analytical total", "Analytical conditional", "Conditional permutation"))


## --------------------------------------------------------------------------------------
quadr <- interaction(cut(infl_W$x, c(-Inf, mean(infl_W$x), Inf), labels=c("Low X", "High X")), cut(infl_W$wx, c(-Inf, mean(infl_W$wx), Inf), labels=c("Low WX", "High WX")), sep=" : ")
a <- table(quadr)
pol_pres15$hs_an_q <- quadr
is.na(pol_pres15$hs_an_q) <- !(pol_pres15$locm_Z < brks[6] | pol_pres15$locm_Z > brks[8])
b <- table(pol_pres15$hs_an_q)
pol_pres15$hs_cp_q <- quadr
is.na(pol_pres15$hs_cp_q) <- !(pol_pres15$locm_p_Z < brks[2] | pol_pres15$locm_p_Z > brks[12])
c <- table(pol_pres15$hs_cp_q)
pol_pres15$hs_ac_q <- quadr
is.na(pol_pres15$hs_ac_q) <- !(pol_pres15$locm_c_Z < brks[2] | pol_pres15$locm_c_Z > brks[12])
d <- table(pol_pres15$hs_ac_q)
t(rbind("Moran plot quadrants"=a, "Unadjusted analytical total"=b, "Bonferroni analytical cond."=d, "Bonferroni cond. perm."=c))


## ----Iihotspots------------------------------------------------------------------------
tm_shape(pol_pres15) + tm_fill(c("hs_an_q", "hs_ac_q", "hs_cp_q"), colorNA="grey95", textNA="Not significant", title="Turnout hotspot status\nLocal Moran's I") + tm_facets(free.scales=FALSE, ncol=2) + tm_layout(panel.labels=c("Unadjusted analytical total", "Bonferroni analytical cond.", "Cond. perm. with Bonferroni"))


## --------------------------------------------------------------------------------------
system.time(z |> 
        localG(lw_q_W) -> locG)


## --------------------------------------------------------------------------------------
system.time(z |> 
        localG_perm(lw_q_W, nsim=499, iseed=1) -> locG_p)


## --------------------------------------------------------------------------------------
locG |> 
    c() |> 
    abs() |> 
    pnorm(lower.tail = FALSE) |> 
    (\(x) x*2)() |> 
    pva() -> pvsp
apply(pvsp, 2, f)


## ----localZvalues----------------------------------------------------------------------
library(ggplot2)
p1 <- ggplot(data.frame(Zi=locm_c[,4], Zi_perm=locm_p[,4])) + geom_point(aes(x=Zi, y=Zi_perm), alpha=0.2) + xlab("Analytical conditional") + ylab("Permutation conditional") + coord_fixed() + ggtitle("Local Moran's I")
p2 <- ggplot(data.frame(Zi=c(locG), Zi_perm=c(locG_p))) + geom_point(aes(x=Zi, y=Zi_perm), alpha=0.2) + xlab("Analytical conditional") + ylab("Permutation conditional") + coord_fixed() + ggtitle("Local G")
gridExtra::grid.arrange(p1, p2, nrow=1)


## --------------------------------------------------------------------------------------
pol_pres15$locG_Z <- c(locG)
pol_pres15$hs_G <- cut(c(locG), c(-Inf, brks[2], brks[12], Inf), labels=c("Low", "Not significant", "High"))
table(pol_pres15$hs_G)


## ----localG----------------------------------------------------------------------------
m1 <- tm_shape(pol_pres15) + tm_fill(c("locG_Z"), midpoint=0, title="Standard\ndeviate")
m2 <- tm_shape(pol_pres15) + tm_fill(c("hs_G"), title="Bonferroni\nhotspot status")
tmap_arrange(m1, m2, nrow=1)


## --------------------------------------------------------------------------------------
# system.time(localI_med_inc_cv <- localmoran(df_tracts$med_inc_cv, lw, alternative="greater"))


## --------------------------------------------------------------------------------------
# system.time(localI_med_inc_cv_cond <- localmoran(df_tracts$med_inc_cv, lw, conditional=TRUE, alternative="greater"))


## ---- eval=FALSE-----------------------------------------------------------------------
## library(parallel)
## set.coresOption(detectCores()-1L)
## # [1] 5
## get.mcOption()
## # [1] TRUE
## system.time(localI_med_inc_cv_perm <- localmoran_perm(df_tracts$med_inc_cv, lw, nsim=499, alternative="greater", iseed=1))
## #    user  system elapsed
## # 113.378   4.688  26.053
## #saveRDS(localI_med_inc_cv_perm, file="localI_med_inc_cv_perm.rds")

## --------------------------------------------------------------------------------------
# ACS_infl <- moran.plot(df_tracts$med_inc_cv, lw, labels=df_tracts$GEOID, cex=1, pch=".", xlab="CV", ylab="lagged CV")


## --------------------------------------------------------------------------------------
# quadr <- interaction(cut(ACS_infl$x, c(-Inf, mean(ACS_infl$x), Inf), labels=c("Low X", "High X")), cut(ACS_infl$wx, c(-Inf, mean(ACS_infl$wx), Inf), labels=c("Low WX", "High WX")), sep=" : ")
# (a <- table(quadr))


## --------------------------------------------------------------------------------------
# df_tracts$hs_an_q <- quadr
# is.na(df_tracts$hs_an_q) <- !(localI_med_inc_cv[, 5] < 0.05)
# b <- table(df_tracts$hs_an_q)
# df_tracts$hs_ac_q <- quadr
# is.na(df_tracts$hs_ac_q) <- !(localI_med_inc_cv_cond[, 5] < 0.05)
# c <- table(df_tracts$hs_ac_q)
# df_tracts$hs_acb_q <- quadr
# is.na(df_tracts$hs_acb_q) <- !(localI_med_inc_cv_cond[, 5] < 0.0000227795)
# d <- table(df_tracts$hs_acb_q)
# t(rbind("Moran plot quadrants"=a, "Unadjusted analytical total"=b, "Unadjusted analytical cond."=c, "Bonferroni analytical cond."=d))

## --------------------------------------------------------------------------------------
# chicago_MA <- read.table("Chicago_MA.txt", colClasses=c("character", "character"))
# chicago_MA_tracts <- !is.na(match(substring(df_tracts$GEOID, 1, 5), chicago_MA$V2))


## --------------------------------------------------------------------------------------
# tm_shape(df_tracts[chicago_MA_tracts,]) + tm_fill(c("hs_an_q", "hs_ac_q", "hs_acb_q"), colorNA="grey95", textNA="Not significant", title="CV hotspot status\nLocal Moran's I") + tm_facets(free.scales=FALSE, ncol=3) + tm_layout(panel.labels=c("Unadjusted total", "Unadjusted conditional", "Bonferroni conditional"))


## --------------------------------------------------------------------------------------
library(rgeoda)
system.time(Geoda_w <- queen_weights(pol_pres15))
summary(Geoda_w)
system.time(lisa <- local_moran(Geoda_w, pol_pres15["I_turnout"], 
    cpu_threads=ifelse(parallel::detectCores() == 1, 1, parallel::detectCores()-1L), permutations=499, seed=1))
all.equal(card(nb_q), lisa_num_nbrs(lisa), check.attributes=FALSE)
all.equal(lisa_values(lisa), localmoran(pol_pres15$I_turnout, listw=lw_q_W, mlvar=FALSE)[,1], check.attributes=FALSE)


## ----sI, echo = TRUE-------------------------------------------------------------------
sessionInfo()

