
## ---- echo=TRUE------------------------------------------------------------------------
needed <- c("sphet", "coda", "spatialreg", "spData", "spdep", "sf")


## --------------------------------------------------------------------------------------
library(sf)
library(spatialreg)

## --------------------------------------------------------------------------------------
boston_506 <- st_read(system.file("shapes/boston_tracts.shp", package="spData")[1])

## --------------------------------------------------------------------------------------
nb_q <- spdep::poly2nb(boston_506)
lw_q <- spdep::nb2listw(nb_q, style="W")


## --------------------------------------------------------------------------------------
table(boston_506$censored)

## --------------------------------------------------------------------------------------
summary(boston_506$median)


## --------------------------------------------------------------------------------------
boston_489 <- boston_506[!is.na(boston_506$median),]
nb_q_489 <- spdep::poly2nb(boston_489)
lw_q_489 <- spdep::nb2listw(nb_q_489, style="W", zero.policy=TRUE)


## --------------------------------------------------------------------------------------
agg_96 <- list(as.character(boston_506$NOX_ID))
boston_96 <- aggregate(boston_506[, "NOX_ID"], by=agg_96, unique)
nb_q_96 <- spdep::poly2nb(boston_96)
lw_q_96 <- spdep::nb2listw(nb_q_96)
boston_96$NOX <- aggregate(boston_506$NOX, agg_96, mean)$x
boston_96$CHAS <- aggregate(as.integer(boston_506$CHAS)-1, agg_96, max)$x


## --------------------------------------------------------------------------------------
nms <- names(boston_506)
ccounts <- 23:31
for (nm in nms[c(22, ccounts, 36)]) {
  boston_96[[nm]] <- aggregate(boston_506[[nm]], agg_96, sum)$x
}
br2 <- c(3.50,  6.25,  8.75, 12.50, 17.50, 22.50, 30.00, 42.50, 60.00)*1000
counts <- as.data.frame(boston_96)[, nms[ccounts]]
f <- function(x) matrixStats::weightedMedian(x=br2, w=x, interpolate=TRUE)
boston_96$median <- apply(counts, 1, f)
is.na(boston_96$median) <- boston_96$median > 50000
summary(boston_96$median)


## ---- echo=FALSE-----------------------------------------------------------------------
POP <- boston_506$POP
f <- function(x) matrixStats::weightedMean(x[,1], x[,2])
for (nm in nms[c(9:11, 14:19, 21, 33)]) {
  s0 <- split(data.frame(boston_506[[nm]], POP), agg_96)
  boston_96[[nm]] <- sapply(s0, f)
}

## --------------------------------------------------------------------------------------
boston_94 <- boston_96[!is.na(boston_96$median),]
nb_q_94 <- spdep::subset.nb(nb_q_96, !is.na(boston_96$median))
lw_q_94 <- spdep::nb2listw(nb_q_94, style="W")


## --------------------------------------------------------------------------------------
form <- formula(log(median) ~ CRIM + ZN + INDUS + CHAS + I((NOX*10)^2) + I(RM^2) + 
                  AGE + log(DIS) + log(RAD) + TAX + PTRATIO + I(BB/100) + 
                  log(I(LSTAT/100)))


## --------------------------------------------------------------------------------------
args(errorsarlm)

## --------------------------------------------------------------------------------------
args(lagsarlm)


## --------------------------------------------------------------------------------------
args(spautolm)


## --------------------------------------------------------------------------------------
args(sacsarlm)


## --------------------------------------------------------------------------------------
args(getS3method("summary", "Sarlm"))


## --------------------------------------------------------------------------------------
eigs_489 <- eigenw(lw_q_489)
SDEM_489 <- errorsarlm(form, data=boston_489, listw=lw_q_489, Durbin=TRUE, 
                       zero.policy=TRUE, control=list(pre_eig=eigs_489))
SEM_489 <- errorsarlm(form, data=boston_489, listw=lw_q_489, 
                      zero.policy=TRUE, control=list(pre_eig=eigs_489))
cbind(data.frame(model=c("SEM", "SDEM")), 
      rbind(broom::tidy(Hausman.test(SEM_489)), 
            broom::tidy(Hausman.test(SDEM_489))))[,1:4]


## --------------------------------------------------------------------------------------
cbind(data.frame(model=c("SEM", "SDEM")), 
      rbind(broom::tidy(LR1.Sarlm(SEM_489)), 
            broom::tidy(LR1.Sarlm(SDEM_489))))[,c(1, 4:6)]


## --------------------------------------------------------------------------------------
eigs_94 <- eigenw(lw_q_94)
SDEM_94 <- errorsarlm(form, data=boston_94, listw=lw_q_94, Durbin=TRUE,
                      control=list(pre_eig=eigs_94))
SEM_94 <- errorsarlm(form, data=boston_94, listw=lw_q_94, control=list(pre_eig=eigs_94))
cbind(data.frame(model=c("SEM", "SDEM")), 
      rbind(broom::tidy(Hausman.test(SEM_94)), 
            broom::tidy(Hausman.test(SDEM_94))))[, 1:4]

## --------------------------------------------------------------------------------------
cbind(data.frame(model=c("SEM", "SDEM")), rbind(broom::tidy(LR1.Sarlm(SEM_94)), broom::tidy(LR1.Sarlm(SDEM_94))))[,c(1, 4:6)]


## --------------------------------------------------------------------------------------
broom::tidy(lmtest::lrtest(SEM_489, SDEM_489))

## --------------------------------------------------------------------------------------
broom::tidy(lmtest::lrtest(SEM_94, SDEM_94))


## --------------------------------------------------------------------------------------
args(lmSLX)


## --------------------------------------------------------------------------------------
SLX_489 <- lmSLX(form, data=boston_489, listw=lw_q_489, zero.policy=TRUE)
broom::tidy(lmtest::lrtest(SLX_489, SDEM_489))


## --------------------------------------------------------------------------------------
SLX_94 <- lmSLX(form, data=boston_94, listw=lw_q_94)
broom::tidy(lmtest::lrtest(SLX_94, SDEM_94))


## --------------------------------------------------------------------------------------
SLX_94w <- lmSLX(form, data=boston_94, listw=lw_q_94, weights=units)
SDEM_94w <- errorsarlm(form, data=boston_94, listw=lw_q_94, Durbin=TRUE, weights=units,
                       control=list(pre_eig=eigs_94))
broom::tidy(lmtest::lrtest(SLX_94w, SDEM_94w))


## --------------------------------------------------------------------------------------
SEM1_94 <- sphet::spreg(form, data=boston_94, listw=lw_q_94, model="error")
res <- rbind(summary(SEM_94)$Coef["I((NOX * 10)^2)",], 
             summary(SEM1_94)$CoefTable["I((NOX * 10)^2)",])
rownames(res) <- c("ML", "GMM")
res


## --------------------------------------------------------------------------------------
formiv <- update(form, . ~ . - I((NOX*10)^2))
boston_94$NOX2 <- (boston_94$NOX*10)^2
suppressWarnings(ccoords <- st_coordinates(st_centroid(st_geometry(boston_94))))
iform <- formula(~poly(ccoords, degree=2) + DIS + RAD)
SEM1_94iv <- sphet::spreg(formiv, data=boston_94, listw=lw_q_94, endog = ~NOX2, 
                   instruments=iform, model="error")
summary(SEM1_94iv)$CoefTable["NOX2",]


## --------------------------------------------------------------------------------------
system.time(SDEM_94B <- spBreg_err(form, data=boston_94, listw=lw_q_94, Durbin=TRUE))


## --------------------------------------------------------------------------------------
system.time(SDEM_489B <- spBreg_err(form, data=boston_489, listw=lw_q_489, Durbin=TRUE, zero.policy=TRUE))


## --------------------------------------------------------------------------------------
t(errorsarlm(form, data=boston_94, listw=lw_q_94, Durbin=TRUE)$timings[,2])

## --------------------------------------------------------------------------------------
t(errorsarlm(form, data=boston_489, listw=lw_q_489, Durbin=TRUE, zero.policy=TRUE)$timings[,2])


## --------------------------------------------------------------------------------------
t(attr(SDEM_94B, "timings")[ , 3])


## --------------------------------------------------------------------------------------
t(attr(SDEM_489B, "timings")[ , 3])


## --------------------------------------------------------------------------------------
SEM_94$interval


## --------------------------------------------------------------------------------------
1/range(eigs_94)


## --------------------------------------------------------------------------------------
1/c(lextrW(lw_q_94))


## --------------------------------------------------------------------------------------
W <- as(lw_q_94, "CsparseMatrix")
1/Re(c(RSpectra::eigs(W, k=1, which="SR")$values, 
       RSpectra::eigs(W, k=1, which="LR")$values))


## --------------------------------------------------------------------------------------
coef <- 0.5
sum(log(1 - coef * eigs_94))


## --------------------------------------------------------------------------------------
I <- Diagonal(nrow(boston_94))
LU <- lu(I - coef * W)
dU <- abs(diag(slot(LU, "U")))
sum(log(dU))


## --------------------------------------------------------------------------------------
W <- as(similar.listw(lw_q_94), "CsparseMatrix")
super <- as.logical(NA)
cch <- Cholesky((I - coef * W), super=super)
c(2 * determinant(cch, logarithm = TRUE)$modulus)


## --------------------------------------------------------------------------------------
args(jacobianSetup)


## --------------------------------------------------------------------------------------
args(do_ldet)


## --------------------------------------------------------------------------------------
args(getS3method("impacts", "Sarlm"))


## --------------------------------------------------------------------------------------
args(getS3method("summary", "LagImpact"))


## --------------------------------------------------------------------------------------
sum_imp_94_SDEM <- summary(impacts(SDEM_94))
rbind(Impacts=sum_imp_94_SDEM$mat[5,], SE=sum_imp_94_SDEM$semat[5,])


## --------------------------------------------------------------------------------------
sum_imp_94_SDEM_B <- summary(impacts(SDEM_94B))
rbind(Impacts=sum_imp_94_SDEM_B$mat[5,], SE=sum_imp_94_SDEM_B$semat[5,])


## --------------------------------------------------------------------------------------
sum_imp_94_SLX <- summary(impacts(SLX_94))
rbind(Impacts=sum_imp_94_SLX$mat[5,], SE=sum_imp_94_SLX$semat[5,])


## --------------------------------------------------------------------------------------
SLM_489 <- lagsarlm(form, data=boston_489, listw=lw_q_489, zero.policy=TRUE)


## --------------------------------------------------------------------------------------
args(trW)

## --------------------------------------------------------------------------------------
W <- as(lw_q_489, "CsparseMatrix")
tr_489 <- trW(W)
str(tr_489)


## --------------------------------------------------------------------------------------
SLM_489_imp <- impacts(SLM_489, tr=tr_489, R=2000)
SLM_489_imp_sum <- summary(SLM_489_imp, short=TRUE, zstats=TRUE)
res <- rbind(Impacts=sapply(SLM_489_imp$res, "[", 5), SE=SLM_489_imp_sum$semat[5,])
colnames(res) <- c("Direct", "Indirect", "Total")
res


## --------------------------------------------------------------------------------------
coef_SLM_489 <- coef(SLM_489)
IrW <- Diagonal(489) - coef_SLM_489[1] * W
S_W <- solve(IrW)
S_NOX_W <- S_W %*% (diag(489) * coef_SLM_489[7])
c(Direct=mean(diag(S_NOX_W)), Total=sum(S_NOX_W)/489)


## --------------------------------------------------------------------------------------
sapply(impacts(SLM_489, listw=lw_q_489), "[", 5)


## --------------------------------------------------------------------------------------
sapply(impacts(SLM_489, evalues=eigs_489), "[", 5)


## --------------------------------------------------------------------------------------
args(getS3method("predict", "sarlm"))


## --------------------------------------------------------------------------------------
nd_489 <- boston_489
nd_489$PTRATIO <- nd_489$PTRATIO + 1
OLS_489 <- lm(form, data=boston_489)
fitted <- predict(OLS_489)
nd_fitted <- predict(OLS_489, newdata=nd_489)
all.equal(unname(coef(OLS_489)[12]), mean(nd_fitted - fitted))


## --------------------------------------------------------------------------------------
fitted <- predict(SLM_489)
nd_fitted <- predict(SLM_489, newdata=nd_489, listw=lw_q_489, pred.type="TS",
                     zero.policy=TRUE)
all.equal(unname(coef_SLM_489[13]), mean(nd_fitted - fitted))


## --------------------------------------------------------------------------------------
nd <- boston_506[is.na(boston_506$median),]
t0 <- exp(predict(SDEM_489, newdata=nd, listw=lw_q, pred.type="TS", zero.policy=TRUE))
suppressWarnings(t1  <- exp(predict(SDEM_489, newdata=nd, listw=lw_q, pred.type="KP2",
                                    zero.policy=TRUE)))
suppressWarnings(t2  <- exp(predict(SDEM_489, newdata=nd, listw=lw_q, pred.type="KP5",
                                    zero.policy=TRUE)))
data.frame(fit_TS=t0[,1], fit_KP2=c(t1), fit_KP5=c(t2),
           censored=boston_506$censored[as.integer(attr(t0, "region.id"))])


## --------------------------------------------------------------------------------------
# library(sf)
# df_tracts <- st_read("df_tracts.gpkg")
# set.ZeroPolicyOption(TRUE)
# spdep::set.ZeroPolicyOption(TRUE)
# nb_subset <- readRDS("nb_subset.rds")
# lw <- spdep::nb2listw(nb_subset, style="W")


## --------------------------------------------------------------------------------------
# tr_form <- log(med_inc_cv) ~ log1p(vacancy_rate) + log1p(old_rate) + log1p(black_rate) + log1p(hisp_rate) + log1p(group_pop) + log1p(dens)


## --------------------------------------------------------------------------------------
# lm_mod <- lm(tr_form, data=df_tracts)
# summary(lm_mod)


## --------------------------------------------------------------------------------------
# spdep::lm.morantest(lm_mod, lw)


## --------------------------------------------------------------------------------------
# SLX <- lmSLX(tr_form, data=df_tracts, listw=lw, zero.policy=TRUE)
# summary(SLX)


## --------------------------------------------------------------------------------------
# spdep::lm.morantest(SLX, lw)


## --------------------------------------------------------------------------------------
# summary(spatialreg::impacts(SLX))


## --------------------------------------------------------------------------------------
# summary(df_tracts$tot_pop)


## --------------------------------------------------------------------------------------
# quantile(df_tracts$group_pop, seq(0, 1, 0.1))


## --------------------------------------------------------------------------------------
# plot(df_tracts$group_pop, df_tracts$group_pop/df_tracts$tot_pop)


## --------------------------------------------------------------------------------------
# plot(df_tracts$tot_pop, df_tracts$group_pop/df_tracts$tot_pop)


## --------------------------------------------------------------------------------------
# lm_modw <- lm(tr_form, data=df_tracts, weights=tot_pop)
# summary(lm_modw)


## --------------------------------------------------------------------------------------
# spdep::lm.morantest(lm_modw, lw)


## --------------------------------------------------------------------------------------
# SLXw <- lmSLX(tr_form, weights=tot_pop, data=df_tracts, listw=lw, zero.policy=TRUE)
# summary(SLXw)


## --------------------------------------------------------------------------------------
# spdep::lm.morantest(SLXw, lw)


## --------------------------------------------------------------------------------------
# summary(spatialreg::impacts(SLXw))


## --------------------------------------------------------------------------------------
# df_tracts$mi_cv_esri <- cut(df_tracts$med_inc_cv, c(0, 0.12, 0.40, Inf), labels=c("High", "Medium", "Low"), right=TRUE, include.lowest=TRUE, ordered_result=TRUE)
# ctr_form <- update(tr_form, . ~ mi_cv_esri/(. -1))
# lm_modc <- lm(ctr_form, data=df_tracts)
# summary(lm_modc)


## --------------------------------------------------------------------------------------
# spdep::lm.morantest(lm_modc, lw)


## --------------------------------------------------------------------------------------
# anova(lm_modc)


## --------------------------------------------------------------------------------------
# anova(lm_mod, lm_modc)


## --------------------------------------------------------------------------------------
# SLXc <- lmSLX(ctr_form, data=df_tracts, listw=lw, zero.policy=TRUE)
# summary(SLXc)


## --------------------------------------------------------------------------------------
# spdep::lm.morantest(SLXc, lw)


## --------------------------------------------------------------------------------------
# summary(spatialreg::impacts(SLXc))


## --------------------------------------------------------------------------------------
# cat(capture.output(print(anova(SLX, SLXc)))[c(1, 2, 27:31)], sep="\n") # anova(SLX, SLXc)


## --------------------------------------------------------------------------------------
# SEM <- spatialreg::errorsarlm(tr_form, data=df_tracts, listw=lw, method="Matrix", zero.policy=TRUE)
# apply(SEM$timings, 2, sum)


## --------------------------------------------------------------------------------------
# summary(SEM, Hausman=TRUE, Nagelkerke=TRUE)


## ---- cache=TRUE-----------------------------------------------------------------------
# set.seed(1)
# BSEM <- spatialreg::spBreg_err(tr_form, data=df_tracts, listw=lw, zero.policy=TRUE)
# apply(attr(BSEM, "timings")[,c(1,3)], 2, sum)


## --------------------------------------------------------------------------------------
# library(coda)
# summary(BSEM)


## --------------------------------------------------------------------------------------
# raftery.diag(BSEM, r=0.01)


## --------------------------------------------------------------------------------------
# plot(BSEM, trace=FALSE)


## --------------------------------------------------------------------------------------
# SEMw <- spatialreg::errorsarlm(tr_form, weights=tot_pop, data=df_tracts, listw=lw, method="Matrix", zero.policy=TRUE)
# apply(SEMw$timings, 2, sum)


## --------------------------------------------------------------------------------------
# summary(SEMw, Hausman=TRUE, Nagelkerke=TRUE)


## --------------------------------------------------------------------------------------
# SEMc <- spatialreg::errorsarlm(ctr_form, weights=tot_pop, data=df_tracts, listw=lw, method="Matrix", zero.policy=TRUE)
# apply(SEMc$timings, 2, sum)


## --------------------------------------------------------------------------------------
# summary(SEMc, Hausman=TRUE, Nagelkerke=TRUE)


## --------------------------------------------------------------------------------------
# anova(SEM, SEMc)


## --------------------------------------------------------------------------------------
# SDEM <- spatialreg::errorsarlm(tr_form, data=df_tracts, listw=lw, method="Matrix", Durbin=TRUE, zero.policy=TRUE)
# apply(SDEM$timings, 2, sum)


## --------------------------------------------------------------------------------------
# summary(SDEM, Nagelkerke=TRUE)


## --------------------------------------------------------------------------------------
# summary(spatialreg::impacts(SDEM))


## --------------------------------------------------------------------------------------
# SDEMw <- spatialreg::errorsarlm(tr_form, weights=tot_pop, data=df_tracts, listw=lw, method="Matrix", Durbin=TRUE, zero.policy=TRUE)
# apply(SDEMw$timings, 2, sum)


## --------------------------------------------------------------------------------------
# summary(SDEMw, Hausman=TRUE, Nagelkerke=TRUE)


## --------------------------------------------------------------------------------------
# summary(spatialreg::impacts(SDEMw))


## --------------------------------------------------------------------------------------
# library(sphet)
# system.time(SEM_GMM <- spreg(tr_form, data=df_tracts, listw=as(lw, "CsparseMatrix"), model="error", het=FALSE))


## --------------------------------------------------------------------------------------
# summary(SEM_GMM)


## --------------------------------------------------------------------------------------
# system.time(SDEM_GMM <- spreg(tr_form, data=df_tracts, listw=as(lw, "CsparseMatrix"), model="error", het=FALSE, Durbin=TRUE))


## --------------------------------------------------------------------------------------
# summary(SDEM_GMM)


## --------------------------------------------------------------------------------------
# system.time(SEM_GMMh <- spreg(tr_form, data=df_tracts, listw=as(lw, "CsparseMatrix"), model="error", het=TRUE))


## --------------------------------------------------------------------------------------
# summary(SEM_GMMh)


## --------------------------------------------------------------------------------------
# system.time(SDEM_GMMh <- spreg(tr_form, data=df_tracts, listw=as(lw, "CsparseMatrix"), model="error", het=TRUE, Durbin=TRUE))


## --------------------------------------------------------------------------------------
# summary(SDEM_GMMh)


## ----sI, echo = TRUE-------------------------------------------------------------------
sessionInfo()

